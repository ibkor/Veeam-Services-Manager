﻿using System.Windows.Forms;

namespace VeeamServiceManager
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstServices = new System.Windows.Forms.ListBox();
            this.btnStartService = new System.Windows.Forms.Button();
            this.btnStopService = new System.Windows.Forms.Button();
            this.btnStartAllServices = new System.Windows.Forms.Button();
            this.btnStopAllServices = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstServices
            // 
            this.lstServices.FormattingEnabled = true;
            this.lstServices.Location = new System.Drawing.Point(12, 12);
            this.lstServices.Name = "lstServices";
            this.lstServices.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstServices.Size = new System.Drawing.Size(480, 368);
            this.lstServices.TabIndex = 0;
            // 
            // btnStartService
            // 
            this.btnStartService.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(96)))));
            this.btnStartService.ForeColor = System.Drawing.Color.White;
            this.btnStartService.Location = new System.Drawing.Point(12, 398);
            this.btnStartService.Name = "btnStartService";
            this.btnStartService.Size = new System.Drawing.Size(75, 23);
            this.btnStartService.TabIndex = 1;
            this.btnStartService.Text = "Start Service";
            this.btnStartService.UseVisualStyleBackColor = false;
            this.btnStartService.Click += new System.EventHandler(this.btnStartService_Click);
            // 
            // btnStopService
            // 
            this.btnStopService.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnStopService.ForeColor = System.Drawing.Color.White;
            this.btnStopService.Location = new System.Drawing.Point(106, 398);
            this.btnStopService.Name = "btnStopService";
            this.btnStopService.Size = new System.Drawing.Size(75, 23);
            this.btnStopService.TabIndex = 2;
            this.btnStopService.Text = "Stop Service";
            this.btnStopService.UseVisualStyleBackColor = false;
            this.btnStopService.Click += new System.EventHandler(this.btnStopService_Click);
            // 
            // btnStartAllServices
            // 
            this.btnStartAllServices.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(170)))), ((int)(((byte)(96)))));
            this.btnStartAllServices.ForeColor = System.Drawing.Color.White;
            this.btnStartAllServices.Location = new System.Drawing.Point(312, 398);
            this.btnStartAllServices.Name = "btnStartAllServices";
            this.btnStartAllServices.Size = new System.Drawing.Size(75, 23);
            this.btnStartAllServices.TabIndex = 3;
            this.btnStartAllServices.Text = "Start All Services";
            this.btnStartAllServices.UseVisualStyleBackColor = false;
            this.btnStartAllServices.Click += new System.EventHandler(this.btnStartAllServices_Click);
            // 
            // btnStopAllServices
            // 
            this.btnStopAllServices.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnStopAllServices.ForeColor = System.Drawing.Color.White;
            this.btnStopAllServices.Location = new System.Drawing.Point(417, 398);
            this.btnStopAllServices.Name = "btnStopAllServices";
            this.btnStopAllServices.Size = new System.Drawing.Size(75, 23);
            this.btnStopAllServices.TabIndex = 4;
            this.btnStopAllServices.Text = "Stop All Services";
            this.btnStopAllServices.UseVisualStyleBackColor = false;
            this.btnStopAllServices.Click += new System.EventHandler(this.btnStopAllServices_Click);
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(504, 429);
            this.Controls.Add(this.btnStopAllServices);
            this.Controls.Add(this.btnStartAllServices);
            this.Controls.Add(this.btnStopService);
            this.Controls.Add(this.btnStartService);
            this.Controls.Add(this.lstServices);
            this.Name = "MainForm";
            this.Text = "Veeam Services Manager";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstServices;
        private System.Windows.Forms.Button btnStartService;
        private System.Windows.Forms.Button btnStopService;
        private Button btnStartAllServices;
        private Button btnStopAllServices;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}