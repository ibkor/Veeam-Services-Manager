﻿using System;
using System.Linq;
using System.ServiceProcess; // Ensure this is included
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeeamServiceManager
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            LoadVeeamServices();
        }

        private void LoadVeeamServices()
        {
            var services = ServiceController.GetServices()
                .Where(s => s.ServiceName.IndexOf("Veeam", StringComparison.OrdinalIgnoreCase) >= 0)
                .ToList();

            foreach (var service in services)
            {
                lstServices.Items.Add(service.ServiceName);
            }
        }

        private async void btnStartService_Click(object sender, EventArgs e)
        {
            int successCount = 0;
            int failureCount = 0;

            await Task.Run(() =>
            {
                foreach (var selectedItem in lstServices.SelectedItems)
                {
                    if (ControlService(selectedItem.ToString(), true))
                    {
                        successCount++;
                    }
                    else
                    {
                        failureCount++;
                    }
                }
            });

            string message = $"Started {successCount} services.";
            if (failureCount > 0)
            {
                message += $" Failed to start {failureCount} services.";
            }
            MessageBox.Show(message);
        }

        private async void btnStopService_Click(object sender, EventArgs e)
        {
            int successCount = 0;
            int failureCount = 0;

            await Task.Run(() =>
            {
                foreach (var selectedItem in lstServices.SelectedItems)
                {
                    if (ControlService(selectedItem.ToString(), false))
                    {
                        successCount++;
                    }
                    else
                    {
                        failureCount++;
                    }
                }
            });

            string message = $"Stopped {successCount} services.";
            if (failureCount > 0)
            {
                message += $" Failed to stop {failureCount} services.";
            }
            MessageBox.Show(message);
        }

        private async void btnStartAllServices_Click(object sender, EventArgs e)
        {
            int successCount = 0;
            int failureCount = 0;

            await Task.Run(() =>
            {
                foreach (var service in lstServices.Items)
                {
                    if (ControlService(service.ToString(), true))
                    {
                        successCount++;
                    }
                    else
                    {
                        failureCount++;
                    }
                }
            });

            string message = $"Started {successCount} services.";
            if (failureCount > 0)
            {
                message += $" Failed to start {failureCount} services.";
            }
            MessageBox.Show(message);
        }

        private async void btnStopAllServices_Click(object sender, EventArgs e)
        {
            int successCount = 0;
            int failureCount = 0;

            await Task.Run(() =>
            {
                foreach (var service in lstServices.Items)
                {
                    if (ControlService(service.ToString(), false))
                    {
                        successCount++;
                    }
                    else
                    {
                        failureCount++;
                    }
                }
            });

            string message = $"Stopped {successCount} services.";
            if (failureCount > 0)
            {
                message += $" Failed to stop {failureCount} services.";
            }
            MessageBox.Show(message);
        }

        private bool ControlService(string serviceName, bool start)
        {
            using (ServiceController service = new ServiceController(serviceName))
            {
                try
                {
                    if (start && service.Status != ServiceControllerStatus.Running)
                    {
                        service.Start();
                        service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30)); // Optional timeout
                    }
                    else if (!start && service.Status != ServiceControllerStatus.Stopped)
                    {
                        service.Stop();
                        service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(30)); // Optional timeout
                    }
                    return true; // Operation was successful
                }
                catch
                {
                    return false; // Operation failed
                }
            }
        }

        private void lstServices_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}